package nl.tue.vmcourse.toy.bci;

import java.util.List;
import java.util.Objects;

public final class CompileContext {
    private final BytecodeBuffer code = new BytecodeBuffer();
    private final List<Objects> constantPool = new List<Objects>();

    public void append(byte[] instrs) {
        for ()

    }
}